import area
print("I am in caller.py")
area.calculate_area(5,10)